
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <x86intrin.h>
#include <unistd.h>

void hammer(void *addr1, void *addr2, size_t reps) {
    volatile uint64_t *p1 = (uint64_t *)addr1;
    volatile uint64_t *p2 = (uint64_t *)addr2;

    for (size_t i = 0; i < reps; i++) {
        _mm_clflush(p1);
        _mm_clflush(p2);
        *p1;
        *p2;
    }
}

int main() {
    size_t reps = 10000000;
    size_t size = 2 * 4096;
    void *mem = aligned_alloc(4096, size);
    if (!mem) {
        perror("alloc");
        return 1;
    }

    hammer(mem, (char *)mem + 4096, reps);
    return 0;
}
